//
//  Session.swift
//  ModelProcessor
//
//  Created by Jayven Nhan on 2021-12-11.
//

import Foundation
import RealityKit
import Combine
import os

private let logger = Logger(subsystem: "com.jayvennhan.sample.ModelProcessor",
                            category: "ModelProcessor")

final class Session {
    // MARK: - Properties
    private let inputFolder: URL
    private let outputFilename: String = "result.usdz"
    private var detail: PhotogrammetrySession.Request.Detail? = nil
    private var subscriber: AnyCancellable?
    let progressStatus = CurrentValueSubject<String, Error>("")
    // MARK: - Initializers
    init(inputFolderFilePath: String) {
        inputFolder = URL(fileURLWithPath: inputFolderFilePath, isDirectory: true)
    }
    // MARK: - Main Methods
    func run() throws {
        let configuration = PhotogrammetrySession.Configuration()
        let session = try PhotogrammetrySession(
            input: inputFolder,
            configuration: configuration
        )
        let task = Task {
            do {
                for try await output in session.outputs {
                    switch output {
                    case .processingComplete:
                        let message = "Processing is complete!"
                        progressStatus.send(message)
                    case .requestError(_, let error):
                        progressStatus.send(completion: .failure(error))
                    case .requestComplete(let request, let result):
                        handleRequestComplete(
                            request: request,
                            result: result
                        )
                    case .requestProgress(_, let fractionComplete):
                        progressStatus.send("\(fractionComplete * 100)")
                    case .inputComplete:  // data ingestion only!
                        progressStatus.send("Data ingestion is complete.  Beginning processing...")
                    case .invalidSample(let id, let reason):
                        progressStatus.send("Invalid Sample! id=\(id)  reason=\"\(reason)\"")
                    case .skippedSample(let id):
                        progressStatus.send("Sample id=\(id) was skipped by processing.")
                    case .automaticDownsampling:
                        progressStatus.send("Automatic downsampling was applied!")
                    case .processingCancelled:
                        progressStatus.send("Processing was cancelled.")
                    @unknown default:
                        progressStatus.send("Output: unhandled message: \(output.localizedDescription)")
                    }
                }
            } catch {
                debugPrint(String(describing: error))
            }
        }
        withExtendedLifetime((session, task)) {
            do {
                let request = makeRequestFromArguments()
                progressStatus.send("Using request: \(String(describing: request))")
                try session.process(requests: [ request ])
//                RunLoop.main.run()
            } catch {
                progressStatus.send("Process got error: \(String(describing: error))")
            }
        }
    }
    // MARK: - Helpers
    private func makeRequestFromArguments() -> PhotogrammetrySession.Request {
        let outputUrl = URL(fileURLWithPath: "/Users/jayven.nhan/Desktop/" + outputFilename)
        if let detailSetting = detail {
            return PhotogrammetrySession.Request.modelFile(url: outputUrl, detail: detailSetting)
        } else {
            return PhotogrammetrySession.Request.modelFile(url: outputUrl)
        }
    }
    private func handleRequestComplete(request: PhotogrammetrySession.Request,
                                       result: PhotogrammetrySession.Result) {
        progressStatus.send("Request complete: \(String(describing: request)) with result...")
        switch result {
        case .modelFile(let url):
            progressStatus.send("\tmodelFile available at url=\(url)")
        default:
            progressStatus.send("\tUnexpected result: \(String(describing: result))")
        }
    }
}

