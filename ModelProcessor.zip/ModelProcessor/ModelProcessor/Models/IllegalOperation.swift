//
//  IllegalOperation.swift
//  ModelProcessor
//
//  Created by Jayven Nhan on 2021-12-11.
//

import Foundation

enum IllegalOption: Swift.Error {
    case invalidDetail(String)
    case invalidSampleOverlap(String)
    case invalidSampleOrdering(String)
    case invalidFeatureSensitivity(String)
}
