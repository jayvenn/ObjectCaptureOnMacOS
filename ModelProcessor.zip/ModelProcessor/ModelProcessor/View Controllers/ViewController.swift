//
//  ViewController.swift
//  ModelProcessor
//
//  Created by Jayven Nhan on 2021-12-11.
//

import Cocoa
import Combine

final class ViewController: NSViewController {
    // MARK: - Properties
    @IBOutlet weak var directoryLabel: NSTextField!
    @IBOutlet weak var progressLabel: NSTextField!
    @IBOutlet weak var progressIndicator: NSProgressIndicator!
    var session: Session?
    private var anyCancellables = Set<AnyCancellable>()
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        progressIndicator.alphaValue = 0
    }
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    // MARK: - Observers
    private func sinkProgress() {
        session?.progressStatus
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
            switch completion {
            case .finished:
                break
            case .failure(let error):
                self.progressLabel.stringValue = error.localizedDescription
            }
        }, receiveValue: {
            guard let fraction = Double($0) else { return }
            self.progressIndicator.doubleValue = fraction
            self.progressLabel.stringValue = "\(round(fraction * 10) / 10.0)%"
        })
            .store(in: &anyCancellables)
    }
    func openFolderSelection() {
        let openPanel = NSOpenPanel()
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseDirectories = true
        openPanel.canCreateDirectories = true
        openPanel.canChooseFiles = false
        openPanel.begin
            { (result) -> Void in
                if result.rawValue == NSApplication.ModalResponse.OK.rawValue
                {
                    guard let url = openPanel.url else { return }
                    self.directoryLabel.stringValue = url.path
                }
        }
    }
    // MARK: - IBActions
    @IBAction func selectFolderAction(_ sender: NSButton) {
        print("ViewController.selectFolderAction(_:)")
        openFolderSelection()
    }
    @IBAction func processImagesAction(_ sender: NSButton) {
        print("ViewController.processImagesAction(_:)")
        progressIndicator.alphaValue = 1
        session = Session(inputFolderFilePath: directoryLabel.stringValue)
        do {
            try session?.run()
        } catch {
            print("Error:", error)
        }
        sinkProgress()
    }
}

