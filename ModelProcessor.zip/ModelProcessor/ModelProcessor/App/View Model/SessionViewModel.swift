//
//  SessionViewModel.swift
//  ModelProcessor
//
//  Created by Jayven Nhan on 2021-12-11.
//

import Foundation

final class SessionViewModel {
}
